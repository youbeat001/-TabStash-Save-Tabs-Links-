@echo off
setlocal EnableDelayedExpansion
REM ============================================================
REM  Build tabstash_host into a single .exe with PyInstaller.
REM  Icon: uses a .ico if present; otherwise, if an image
REM  (.png/.jpg/.jpeg/.bmp/.gif/.webp) is in this folder, it is
REM  converted to .ico (via Pillow) and used as the exe icon.
REM  On success: move the exe next to this script, delete the
REM  build\ and dist\ folders, the .spec and the generated icon,
REM  then close.
REM ============================================================

set "DEST_DIR=%~dp0"
set "PY_FILE=%DEST_DIR%tabstash_host.py"

if not exist "%PY_FILE%" (
    echo ERROR: tabstash_host.py not found in "%DEST_DIR%"
    pause
    exit /b 1
)

cd /d "%DEST_DIR%"

REM ---- choose an icon ----
set "ICON_FILE="
set "GEN_ICON="

REM 1) an existing .ico wins
for %%I in ("%DEST_DIR%*.ico") do if not defined ICON_FILE set "ICON_FILE=%%~fI"

REM 2) otherwise take the first image and convert it to .ico
if not defined ICON_FILE (
    set "IMG_FILE="
    for %%E in (png jpg jpeg bmp gif webp) do (
        if not defined IMG_FILE for %%I in ("%DEST_DIR%*.%%E") do if not defined IMG_FILE set "IMG_FILE=%%~fI"
    )
    if defined IMG_FILE call :make_icon
)

echo Building tabstash_host.exe ...
if defined ICON_FILE (
    echo Using icon: !ICON_FILE!
    pyinstaller --onefile --noconsole --icon="!ICON_FILE!" ^
        --hidden-import=cryptography --collect-submodules=cryptography ^
        --name tabstash_host tabstash_host.py
) else (
    pyinstaller --onefile --noconsole ^
        --hidden-import=cryptography --collect-submodules=cryptography ^
        --name tabstash_host tabstash_host.py
)

if not exist "%DEST_DIR%dist\tabstash_host.exe" (
    echo.
    echo Build failed - exe not found. Check the messages above.
    pause
    exit /b 1
)

REM move the exe out of dist, next to this script
move /Y "%DEST_DIR%dist\tabstash_host.exe" "%DEST_DIR%tabstash_host.exe" >nul

REM remove build artifacts that are no longer needed
rmdir /S /Q "%DEST_DIR%build" 2>nul
rmdir /S /Q "%DEST_DIR%dist" 2>nul
del /Q "%DEST_DIR%tabstash_host.spec" 2>nul
if defined GEN_ICON del /Q "%DEST_DIR%tabstash_icon.ico" 2>nul

echo.
echo DONE: %DEST_DIR%tabstash_host.exe
echo Closing...
timeout /t 3 /nobreak >nul
exit /b 0

REM ---- subroutines (kept out of if-blocks so Python parentheses are safe) ----
:make_icon
echo Converting "!IMG_FILE!" to an icon...
call :do_convert
if not exist "%DEST_DIR%tabstash_icon.ico" (
    echo Installing Pillow...
    python -m pip install --quiet pillow >nul 2>nul
    call :do_convert
)
if exist "%DEST_DIR%tabstash_icon.ico" (
    set "ICON_FILE=%DEST_DIR%tabstash_icon.ico"
    set "GEN_ICON=1"
    echo Icon created.
) else (
    echo Could not create a custom icon - building without one.
)
goto :eof

:do_convert
python -c "from PIL import Image; Image.open(r'!IMG_FILE!').convert('RGBA').save(r'!DEST_DIR!tabstash_icon.ico', sizes=[(16,16),(24,24),(32,32),(48,48),(64,64),(128,128),(256,256)])" >nul 2>nul
goto :eof