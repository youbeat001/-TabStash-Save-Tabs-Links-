@echo off
setlocal EnableExtensions EnableDelayedExpansion
REM ============================================================================
REM  setup_firefox.bat  (TabStash - Firefox / Mullvad)  -- all-in-one
REM
REM  Does, in one run:
REM    1. Registers the native host (writes com.tabstash.host.firefox.json,
REM       creates run_host.bat if missing, writes the HKCU registry key).
REM    2. Lets you pick an existing per-browser profile or type a new UUID.
REM    3. Optionally seeds that profile's key/vault from a SOURCE you choose
REM       (Main vault, or another existing profile).
REM    4. Drops "open_vault.bat" inside the profile so you can open the tool
REM       straight on that vault (uses tabstash_host.exe).
REM
REM  Put this .bat in the tool folder (next to tabstash_host.py / .exe).
REM  Find a browser's UUID in about:debugging -> This Firefox -> TabStash.
REM ============================================================================

REM ---------------- CONFIG ----------------
set "HOST_NAME=com.tabstash.host"
set "EXT_ID=tabstash@silverrabbit.local"
set "DESCR=TabStash encrypted vault native host"
set "OUTNAME=com.tabstash.host.firefox.json"
set "PYNAME=tabstash_host.py"
set "EXENAME=tabstash_host.exe"
set "RUNNAME=run_host.bat"
set "HOSTARG=host"
REM ----------------------------------------

set "HERE=%~dp0"
if "%HERE:~-1%"=="\" set "HERE=%HERE:~0,-1%"
set "MANIFEST=%HERE%\%OUTNAME%"
set "PROFDIR=%HERE%\profiles"
set "SRC_KEY=%HERE%\tabstash.key"
set "SRC_VAULT=%HERE%\tabstash.vault"

echo ============================================================
echo TabStash - Firefox setup (register + profiles + seed)
echo ============================================================
echo Folder: %HERE%
echo.

REM ============================================================
REM  PART 1 - REGISTER NATIVE HOST  (from register_firefox_host_v3)
REM ============================================================

REM ---- locate the python host script (this folder or one below) ----
set "HOSTPY="
if exist "%HERE%\%PYNAME%" set "HOSTPY=%HERE%\%PYNAME%"
if not defined HOSTPY (
    for /d %%D in ("%HERE%\*") do (
        if not defined HOSTPY if exist "%%~fD\%PYNAME%" set "HOSTPY=%%~fD\%PYNAME%"
    )
)
if not defined HOSTPY (
    echo [ERROR] %PYNAME% not found here or one level below.
    pause
    exit /b 1
)
for %%F in ("!HOSTPY!") do set "TOOLDIR=%%~dpF"
if "!TOOLDIR:~-1!"=="\" set "TOOLDIR=!TOOLDIR:~0,-1!"

REM ---- locate the .exe (needed for the per-profile shortcut) ----
set "HOSTEXE="
if exist "!TOOLDIR!\%EXENAME%" set "HOSTEXE=!TOOLDIR!\%EXENAME%"
if not defined HOSTEXE if exist "%HERE%\%EXENAME%" set "HOSTEXE=%HERE%\%EXENAME%"

REM ---- locate python.exe ----
set "PY="
if not "%~1"=="" set "PY=%~f1"
if not defined PY (
    for /d %%D in ("%LOCALAPPDATA%\Programs\Python\Python3*") do (
        if not defined PY if exist "%%~fD\python.exe" set "PY=%%~fD\python.exe"
    )
)
if not defined PY (
    for /d %%D in ("%ProgramFiles%\Python3*") do (
        if not defined PY if exist "%%~fD\python.exe" set "PY=%%~fD\python.exe"
    )
)
if not defined PY (
    for /f "delims=" %%P in ('where python.exe 2^>nul') do (
        if not defined PY echo %%P | find /i "WindowsApps" >nul || set "PY=%%P"
    )
)
if not defined PY (
    echo [ERROR] python.exe not found. Pass it explicitly:
    echo         %~nx0 "C:\full\path\to\python.exe"
    pause
    exit /b 1
)

REM ---- create run_host.bat next to the .py, only if missing ----
set "RUNBAT=!TOOLDIR!\%RUNNAME%"
if not exist "!RUNBAT!" (
    > "!RUNBAT!" (
        echo @echo off
        echo "!PY!" "!HOSTPY!" %HOSTARG%
    )
    echo Launcher       : !RUNBAT!  [created]
) else (
    echo Launcher       : !RUNBAT!  [kept]
)

REM ---- write manifest (overwrite with correct data) ----
set "JSONPATH=!RUNBAT:\=\\!"
if exist "%MANIFEST%" del /f /q "%MANIFEST%" >nul 2>&1
> "%MANIFEST%" (
    echo {
    echo   "name": "%HOST_NAME%",
    echo   "description": "%DESCR%",
    echo   "path": "!JSONPATH!",
    echo   "type": "stdio",
    echo   "allowed_extensions": ["%EXT_ID%"]
    echo }
)
if not exist "%MANIFEST%" (
    echo [ERROR] Could not write %MANIFEST%
    pause
    exit /b 1
)
echo Manifest       : %MANIFEST%  [written]

REM ---- registry key ----
reg add "HKCU\Software\Mozilla\NativeMessagingHosts\%HOST_NAME%" /ve /t REG_SZ /d "%MANIFEST%" /f >nul
if errorlevel 1 (
    echo [ERROR] Could not write the registry key.
    pause
    exit /b 1
)
echo Registry       : HKCU\...\NativeMessagingHosts\%HOST_NAME%  [ok]
echo.

REM ============================================================
REM  PART 2 - CHOOSE / CREATE A PROFILE
REM ============================================================

echo ------------------------------------------------------------
echo Profiles (per-browser vaults)
echo ------------------------------------------------------------

REM ---- build a numbered list of existing profiles ----
set "N=0"
if exist "%PROFDIR%" (
    for /d %%D in ("%PROFDIR%\*") do (
        set /a N+=1
        set "PROF[!N!]=%%~nxD"
        echo    !N!^) %%~nxD
    )
)
if "!N!"=="0" echo    (no profiles yet)
echo    M^) Type a new UUID manually
echo.

set "PICK="
set /p "PICK=Choose a profile number, or M for manual: "

set "UUID="
if /i "!PICK!"=="M" goto :MANUAL
if defined PROF[%PICK%] (
    set "UUID=!PROF[%PICK%]!"
    goto :HAVE_UUID
)
echo Invalid choice, switching to manual entry.

:MANUAL
set /p "UUID=Paste the extension Internal UUID: "
if not defined UUID (
    echo [ERROR] No UUID entered.
    pause
    exit /b 1
)

:HAVE_UUID
REM ---- sanitize (strip path separators / dots / spaces) ----
set "UUID=!UUID: =!"
set "UUID=!UUID:\=!"
set "UUID=!UUID:/=!"
set "UUID=!UUID::=!"
set "UUID=!UUID:.=!"
if not defined UUID (
    echo [ERROR] UUID has no valid characters.
    pause
    exit /b 1
)
set "TARGET=%PROFDIR%\!UUID!"
echo.
echo Target profile : !TARGET!
echo.

REM ---- confirm overwrite if profile already has data ----
set "EXISTS=0"
if exist "!TARGET!\tabstash.vault" set "EXISTS=1"
if exist "!TARGET!\tabstash.key"   set "EXISTS=1"
if "!EXISTS!"=="1" (
    set "OW="
    set /p "OW=Profile exists with data. Overwrite key/vault? (y/N): "
    if /i not "!OW!"=="y" (
        echo Kept existing profile data. ^(Shortcut will still be refreshed.^)
        goto :SHORTCUT
    )
)

REM ============================================================
REM  PART 3 - CHOOSE SEED SOURCE (Main or another profile)
REM ============================================================
echo ------------------------------------------------------------
echo Seed this profile's data FROM:
echo ------------------------------------------------------------
echo    0^) Main vault ^(tabstash.key / tabstash.vault here^)
set "S=0"
if exist "%PROFDIR%" (
    for /d %%D in ("%PROFDIR%\*") do (
        if /i not "%%~nxD"=="!UUID!" (
            set /a S+=1
            set "SRC[!S!]=%%~fD"
            set "SRCN[!S!]=%%~nxD"
            echo    !S!^) profile %%~nxD
        )
    )
)
echo    E^) Empty ^(no import; host creates a fresh key+vault^)
echo.
set "SPICK="
set /p "SPICK=Choose seed source: "

set "SEED_KEY="
set "SEED_VAULT="
if /i "!SPICK!"=="E" goto :NOSEED
if "!SPICK!"=="0" (
    set "SEED_KEY=%SRC_KEY%"
    set "SEED_VAULT=%SRC_VAULT%"
    goto :ASKWHAT
)
if defined SRC[%SPICK%] (
    set "SEED_KEY=!SRC[%SPICK%]!\tabstash.key"
    set "SEED_VAULT=!SRC[%SPICK%]!\tabstash.vault"
    goto :ASKWHAT
)
echo Invalid choice -> no import.
goto :NOSEED

:ASKWHAT
set "HAVE_K=0"
set "HAVE_V=0"
if exist "!SEED_KEY!"   set "HAVE_K=1"
if exist "!SEED_VAULT!" set "HAVE_V=1"
echo.
if "!HAVE_K!"=="1" (echo Source key   : found) else (echo Source key   : NOT found)
if "!HAVE_V!"=="1" (echo Source vault : found) else (echo Source vault : NOT found)
echo.

set "DO_KEY=0"
if "!HAVE_K!"=="1" (
    set "A="
    set /p "A=Import the key? (Y/n): "
    if /i not "!A!"=="n" set "DO_KEY=1"
)
set "DO_VAULT=0"
if "!HAVE_V!"=="1" (
    set "A="
    set /p "A=Import the vault? (Y/n): "
    if /i not "!A!"=="n" set "DO_VAULT=1"
)

REM ---- block vault-without-key (unreadable) ----
if "!DO_VAULT!"=="1" if "!DO_KEY!"=="0" (
    echo.
    echo [BLOCKED] Importing the vault without its key would be unreadable.
    echo Import BOTH, or neither.
    pause
    exit /b 1
)

if not exist "!TARGET!" mkdir "!TARGET!" 2>nul
if "!DO_KEY!"=="1"   copy /y "!SEED_KEY!"   "!TARGET!\tabstash.key"   >nul && echo Copied key.
if "!DO_VAULT!"=="1" copy /y "!SEED_VAULT!" "!TARGET!\tabstash.vault" >nul && echo Copied vault.
goto :SHORTCUT

:NOSEED
if not exist "!TARGET!" mkdir "!TARGET!" 2>nul
echo Empty profile (host will create key+vault on first use).

:SHORTCUT
REM ============================================================
REM  PART 4 - PER-PROFILE SHORTCUT (.bat) to open this vault
REM ============================================================
if not exist "!TARGET!" mkdir "!TARGET!" 2>nul
set "OPENBAT=!TARGET!\open_vault.bat"
if defined HOSTEXE (
    > "!OPENBAT!" (
        echo @echo off
        echo "!HOSTEXE!" gui !UUID!
    )
    echo Shortcut       : !OPENBAT!  ^(uses tabstash_host.exe^)
) else (
    > "!OPENBAT!" (
        echo @echo off
        echo "!PY!" "!HOSTPY!" gui !UUID!
    )
    echo Shortcut       : !OPENBAT!  ^(exe not found; uses python^)
    echo [note] To use the .exe, build it with your build_host_exe.bat, then
    echo        re-run this to refresh the shortcut.
)

echo.
echo ============================================================
echo DONE
echo ============================================================
echo Profile folder : !TARGET!
echo Open its vault : run  open_vault.bat  inside that folder
echo Restart the browser with UUID !UUID! to use it.
echo.
pause
endlocal
