# TabStash Tool (encrypted vault + editor) v1.2.2

Native companion for TabStash. Stores the active groups in a local encrypted,
portable file and provides a full editor GUI.

## Sync (3-way merge, extension authoritative)
The extension sends its last agreed snapshot (base) + current groups; the host
merges base + extension + its own vault:
- Extension deletions win: trashing removes from the vault, restoring re-adds.
- Genuine tool-side additions/edits (new links/groups, paste, import) are kept.
- On conflicts the extension wins. Only active groups are synced.

## Realtime
The GUI auto-refreshes when the browser changes the list, and a connected
extension page auto-refreshes when you edit in the GUI (the host watches the
vault file and notifies the extension).

## Editor (GUI)
- Groups open collapsed; click u25b8 to expand a group (its links build on demand,
  in chunks), so the window opens instantly even with thousands of links.
Double-click tabstash_host.py (or the built exe) to open it:
- New group, rename (type + Enter), reorder groups (up/down), delete group.
- Paste links (one per line: 'url' or 'title | url') into a chosen/new group.
- Per link: Open (browser), Copy (URL to clipboard), up/down, move to group, delete.
- Import / Export JSON (compatible with the extension's export).

## Encryption
- tabstash.vault (AES-256-GCM), tabstash.key (32-byte key), tabstash.vault.bak.
- No master password: useless online/on its own; readable only with LOCAL access
  to both files. To move to another PC, copy vault + key together.

## Setup (Windows)
1. Keep this folder stable. 2. Load the extension (v1.3.0), copy its ID from
chrome://extensions. 3. Run install_host.bat, paste the ID. 4. Reload the
extension page; the icon light turns green. 5. Optional: build_host_exe.bat.

## Commands
python tabstash_host.py gui | host | install <EXT_ID> | dump

Note: with the extension connected it is authoritative; editing an item that the
extension also has may be overridden by the extension on the next sync. Tool-only
additions are always preserved.
