#!/usr/bin/env python3
"""
tabstash_host.py - TabStash native host + encrypted local vault (v1.3.7)

v1.3.0: robust framing (readexact) + chunked sync/pull so huge tab lists no
longer exceed Firefox's 1 MB native-message limit and kill the host. Legacy
monolithic "sync"/"pull" still handled for older extensions.

Stores the tab list (groups only) in a local encrypted file, portable across
PCs (copy tabstash.vault + tabstash.key together). No master password: the AES
key lives in a local key file, so the vault is useless online / on its own but
readable by anyone with local access to BOTH files.

Sync model (3-way merge, extension is authoritative):
  The extension sends its last agreed snapshot (base) + its current groups. The
  host merges base + extension + its own vault. Extension deletions win (trashing
  removes from the vault, restoring re-adds); genuine vault-side additions/edits
  are kept. Only active groups are synced; the extension keeps its own trash.

The GUI is a full editor: create groups, add/paste links, move/copy/open links,
delete, import & export.

Commands:
  python tabstash_host.py gui               # open the editor
  python tabstash_host.py host              # run as Chrome native messaging host
  python tabstash_host.py install <EXT_ID>  # register the native host (Windows)
  python tabstash_host.py dump              # print decrypted vault (debug)
"""

import sys
import os
import json
import time
import struct
import base64
import secrets
import threading
import webbrowser
import traceback
from pathlib import Path
from urllib.parse import urlparse

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

HOST_NAME = "com.tabstash.host"  # must match the extension's HOST_NAME

_stdout_lock = threading.Lock()
_self_mtimes = set()  # vault mtimes written by THIS process (to ignore our own writes)


def _app_dir():
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


APP_DIR = _app_dir()
VAULT_FILE = APP_DIR / "tabstash.vault"
KEY_FILE = APP_DIR / "tabstash.key"


def _uid():
    return format(int(time.time() * 1000), "x") + secrets.token_hex(3)


def _hostname(url):
    try:
        return urlparse(url).hostname or url
    except Exception:
        return url


# ---------- crypto: AES-256-GCM with a local key file ----------
def load_or_create_key():
    if KEY_FILE.exists():
        return base64.b64decode(KEY_FILE.read_bytes())
    key = secrets.token_bytes(32)
    KEY_FILE.write_bytes(base64.b64encode(key))
    try:
        if os.name == "posix":
            os.chmod(KEY_FILE, 0o600)
    except Exception:
        pass
    return key


def encrypt(text, key):
    nonce = secrets.token_bytes(12)
    ct = AESGCM(key).encrypt(nonce, text.encode("utf-8"), None)
    return base64.b64encode(nonce + ct)


def decrypt(blob, key):
    raw = base64.b64decode(blob)
    nonce, ct = raw[:12], raw[12:]
    return AESGCM(key).decrypt(nonce, ct, None).decode("utf-8")


# ---------- vault I/O (groups only) ----------
def load_vault():
    if not VAULT_FILE.exists():
        return {"groups": []}
    key = load_or_create_key()
    # Retry a few times: another process (the extension's background page, or a
    # second host spawned for the badge) may be mid-write, so a single read can
    # catch a half-written file. Only give up after several attempts, and NEVER
    # quarantine the vault on a transient error (that used to wipe real data).
    last_exc = None
    for attempt in range(6):
        try:
            v = json.loads(decrypt(VAULT_FILE.read_bytes(), key))
            v.setdefault("groups", [])
            return v
        except Exception as e:
            last_exc = e
            time.sleep(0.15)
    # Persistent failure: fall back to the .bak if present, else return empty
    # WITHOUT destroying the current file, so nothing is lost by accident.
    try:
        bak = VAULT_FILE.with_suffix(".bak")
        if bak.exists():
            v = json.loads(decrypt(bak.read_bytes(), key))
            v.setdefault("groups", [])
            return v
    except Exception:
        pass
    return {"groups": []}


def _vault_mtime():
    try:
        return VAULT_FILE.stat().st_mtime_ns
    except OSError:
        return 0


def save_vault(vault):
    key = load_or_create_key()
    blob = encrypt(json.dumps({"groups": vault.get("groups", [])}, ensure_ascii=False), key)
    if VAULT_FILE.exists():
        try:
            VAULT_FILE.replace(VAULT_FILE.with_suffix(".bak"))
        except Exception:
            pass
    tmp = VAULT_FILE.with_suffix(".tmp")
    tmp.write_bytes(blob)
    os.replace(tmp, VAULT_FILE)
    try:
        _self_mtimes.add(_vault_mtime())  # remember our own write
    except Exception:
        pass


# ---------- 3-way merge (extension authoritative) ----------
def _index(groups):
    gmeta, gorder, lplace, lobj, lorder = {}, [], {}, {}, {}
    for g in groups or []:
        gid = g.get("id")
        if gid is None:
            continue
        gmeta[gid] = {"name": g.get("name", ""),
                      "collapsed": bool(g.get("collapsed", False)),
                      "createdAt": g.get("createdAt")}
        gorder.append(gid)
        lorder.setdefault(gid, [])
        for l in g.get("links", []) or []:
            lid = l.get("id")
            if lid is None:
                continue
            lplace[lid] = gid
            lobj[lid] = l
            lorder[gid].append(lid)
    return dict(gmeta=gmeta, gorder=gorder, lplace=lplace, lobj=lobj, lorder=lorder)


def three_way_merge(base, a, b):
    """base = last agreed snapshot, a = extension (authoritative), b = tool."""
    B, A, T = _index(base), _index(a), _index(b)
    now = int(time.time() * 1000)

    def survives(inA, inT, inB):
        return inA or (inT and not inB)

    survive_g = {gid for gid in set(A["gmeta"]) | set(T["gmeta"]) | set(B["gmeta"])
                 if survives(gid in A["gmeta"], gid in T["gmeta"], gid in B["gmeta"])}
    survive_l = {lid for lid in set(A["lplace"]) | set(T["lplace"]) | set(B["lplace"])
                 if survives(lid in A["lplace"], lid in T["lplace"], lid in B["lplace"])}

    def meta(gid):
        a_ = A["gmeta"].get(gid)
        t_ = T["gmeta"].get(gid)
        b_ = B["gmeta"].get(gid)
        out = {}
        for f in ("name", "collapsed", "createdAt"):
            av = a_[f] if a_ else None
            tv = t_[f] if t_ else None
            bv = b_[f] if b_ else None
            if a_ and av != bv:
                out[f] = av
            elif t_ and tv != bv:
                out[f] = tv
            elif a_:
                out[f] = av
            elif t_:
                out[f] = tv
            else:
                out[f] = bv
        if not out.get("createdAt"):
            out["createdAt"] = now
        return out

    def place(lid):
        a_ = A["lplace"].get(lid)
        t_ = T["lplace"].get(lid)
        b_ = B["lplace"].get(lid)
        if a_ is not None and a_ != b_:
            g = a_
        elif t_ is not None and t_ != b_:
            g = t_
        elif a_ is not None:
            g = a_
        elif t_ is not None:
            g = t_
        else:
            g = b_
        if g not in survive_g:
            for cand in (a_, t_, b_):
                if cand in survive_g:
                    g = cand
                    break
        return g

    def link_obj(lid):
        a_ = A["lobj"].get(lid)
        t_ = T["lobj"].get(lid)
        b_ = B["lobj"].get(lid)
        base_l = b_ or {}
        if a_ and a_ != base_l:
            src = a_
        elif t_ and t_ != base_l:
            src = t_
        else:
            src = a_ or t_ or b_ or {}
        return {"id": lid, "title": src.get("title", ""),
                "url": src.get("url", ""), "favIconUrl": src.get("favIconUrl", "")}

    order = []
    for gid in A["gorder"] + T["gorder"] + B["gorder"]:
        if gid in survive_g and gid not in order:
            order.append(gid)

    groups = {}
    for gid in order:
        m = meta(gid)
        groups[gid] = {"id": gid, "name": m["name"],
                       "collapsed": bool(m["collapsed"]),
                       "createdAt": m["createdAt"], "links": []}

    assigned = set()

    def add_link(lid):
        if lid in assigned or lid not in survive_l:
            return
        gid = place(lid)
        if gid not in groups:
            m = meta(gid)
            groups[gid] = {"id": gid, "name": m["name"],
                           "collapsed": bool(m["collapsed"]),
                           "createdAt": m["createdAt"] or now, "links": []}
            order.append(gid)
        groups[gid]["links"].append(link_obj(lid))
        assigned.add(lid)

    for gid in A["gorder"]:
        for lid in A["lorder"].get(gid, []):
            add_link(lid)
    for gid in T["gorder"]:
        for lid in T["lorder"].get(gid, []):
            add_link(lid)
    for gid in B["gorder"]:
        for lid in B["lorder"].get(gid, []):
            add_link(lid)

    return [groups[gid] for gid in order if gid in groups]


# ---------- native messaging protocol ----------
# Firefox caps a single native message at 1 MB in BOTH directions. Large tab
# lists blow past that, so the extension now streams "sync" in chunks (see
# handle()). Here we only guarantee correct framing: read/write the exact byte
# count, never partial. read() on a pipe can return fewer bytes than asked, so
# we loop until we have them all.
def _readexact(n):
    buf = bytearray()
    while len(buf) < n:
        piece = sys.stdin.buffer.read(n - len(buf))
        if not piece:
            return None  # EOF / pipe closed
        buf.extend(piece)
    return bytes(buf)


def _read_message():
    raw = _readexact(4)
    if raw is None:
        return None
    n = struct.unpack("<I", raw)[0]
    body = _readexact(n)
    if body is None:
        return None
    return json.loads(body.decode("utf-8"))


def _send_message(obj):
    data = json.dumps(obj).encode("utf-8")
    # A host->ext message over 1 MB would be dropped by Firefox and desync the
    # port. "pull"/"sync" replies can be huge, so the extension pulls them in
    # chunks (action:"pull_chunk"); this guard just protects against accidents.
    with _stdout_lock:
        sys.stdout.buffer.write(struct.pack("<I", len(data)))
        sys.stdout.buffer.write(data)
        sys.stdout.buffer.flush()


def _watch_loop():
    """Deprecated. The push model (writing an unsolicited 'changed' event on the
    shared stdout) races with RPC replies and corrupts the native-message frame
    on Windows, killing the port. The extension now POLLS via action:"poll"
    instead, so this thread is never started."""
    return


_watcher_started = False

# Reassembly buffers for chunked sync (browser -> host), keyed by transfer id.
# Each entry: {"base":[...], "groups":[...], "ts":<mtime>}.
_rx = {}
# Snapshots for paginated pull (host -> browser), keyed by transfer id.
_tx = {}
MAX_LIVE_TX = 8  # cap stale snapshots
# Mullvad/Tor Browser can drop native messages well below Firefox's 1 MB limit.
# Keep every host->browser message comfortably small.
MAX_MSG_BYTES = 128 * 1024


def _do_sync(base, ext):
    """Run the 3-way merge and persist. Returns the merged groups list."""
    v = load_vault()
    tool = v.get("groups", [])
    merged = three_way_merge(base, ext, tool)
    if merged != tool:
        v["groups"] = merged
        save_vault(v)
    return merged


def _stash_pull(tid, groups):
    """Store a snapshot for paginated retrieval; return total count."""
    if len(_tx) >= MAX_LIVE_TX:
        _tx.clear()
    _tx[tid] = groups
    return len(groups)


def handle(req):
    global _watcher_started
    # watch flag kept for backward compat but no longer starts a pushing thread
    # (see _watch_loop). The extension polls with action:"poll" instead.

    action = req.get("action")

    if action == "status":
        v = load_vault()
        return {"ok": True, "vaultExists": VAULT_FILE.exists(),
                "groups": len(v.get("groups", [])), "mtime": _vault_mtime()}

    # cheap change check: return the vault mtime so the extension can detect
    # tool-side edits by polling, without pushing anything on the shared stdout.
    if action == "poll":
        return {"ok": True, "mtime": _vault_mtime()}

    # ----- legacy monolithic path (kept for old extensions) -----
    if action == "pull":
        return {"ok": True, "groups": load_vault().get("groups", [])}

    if action == "sync":
        merged = _do_sync(req.get("base", []), req.get("groups", []))
        return {"ok": True, "groups": merged}

    # ----- chunked sync (browser -> host) -----
    # sync_begin {tid}                     : start a transfer
    # sync_chunk {tid, kind:"base"|"groups", items:[...]} : append groups
    # sync_end   {tid}                     : merge, then reply chunked via pull
    if action == "sync_begin":
        tid = req.get("tid")
        _rx[tid] = {"base": [], "groups": []}
        return {"ok": True, "tid": tid}

    if action == "sync_chunk":
        tid = req.get("tid")
        slot = _rx.get(tid)
        if slot is None:
            return {"ok": False, "error": "no_transfer"}
        kind = req.get("kind")
        if kind not in ("base", "groups"):
            return {"ok": False, "error": "bad_kind"}
        slot[kind].extend(req.get("items", []))
        return {"ok": True}

    if action == "sync_end":
        tid = req.get("tid")
        slot = _rx.pop(tid, None)
        if slot is None:
            return {"ok": False, "error": "no_transfer"}
        # Groups may arrive split across chunks (same id, partial link lists) so
        # that a single huge group never travels in one oversized message.
        # Coalesce fragments here before merging.
        base = _coalesce_fragments(slot["base"])
        groups = _coalesce_fragments(slot["groups"])
        merged = _do_sync(base, groups)
        total = _stash_pull(tid, merged)
        # reply is retrieved by the extension via pull_chunk (never >1 MB)
        return {"ok": True, "tid": tid, "total": total, "chunked": True,
                "mtime": _vault_mtime()}

    # ----- paginated pull (host -> browser) -----
    # pull_begin {}     : snapshot current vault, return {tid,total}
    if action == "pull_begin":
        tid = _uid()
        total = _stash_pull(tid, load_vault().get("groups", []))
        return {"ok": True, "tid": tid, "total": total, "chunked": True,
                "mtime": _vault_mtime()}

    # pull_chunk {tid,off} : return as many groups from `off` as fit under a
    #   byte budget (Mullvad/Tor can drop native messages well under 1 MB, so we
    #   cap by size, not by a fixed group count). Always returns >=1 group to
    #   guarantee progress even if a single group is large.
    # pull_chunk {tid, gi, li} : return a byte-bounded slice starting at group
    #   index gi, link index li. A group whose links don't all fit is emitted in
    #   several pieces (same id, "partial":true until its last piece). This keeps
    #   every message small even for a single group with thousands of links.
    #   Reply: {items:[{...group, links:[...], partial:bool}], next_gi, next_li,
    #           done}. The extension stitches partials back together by id.
    if action == "pull_chunk":
        tid = req.get("tid")
        groups = _tx.get(tid)
        if groups is None:
            return {"ok": False, "error": "no_transfer"}
        budget = int(req.get("budget", MAX_MSG_BYTES))
        # accept legacy {off} as {gi:off, li:0}
        gi = int(req.get("gi", req.get("off", 0)))
        li = int(req.get("li", 0))
        # per-link byte budget: leave generous headroom for metadata, JSON
        # overhead and framing so the final message stays well under budget
        link_budget = max(8 * 1024, budget // 2)

        items = []
        size = 0
        while gi < len(groups):
            g = groups[gi]
            links = g.get("links", []) or []
            # start a piece of this group at link index li
            piece_links = []
            piece_size = 0
            k = li
            while k < len(links):
                lb = len(json.dumps(links[k], ensure_ascii=False).encode("utf-8"))
                if piece_links and piece_size + lb > link_budget:
                    break
                piece_links.append(links[k])
                piece_size += lb
                k += 1
            partial = k < len(links)  # group continues in a later message
            item = {"id": g.get("id"), "name": g.get("name", ""),
                    "collapsed": bool(g.get("collapsed", False)),
                    "createdAt": g.get("createdAt"),
                    "links": piece_links, "partial": partial}
            item_bytes = len(json.dumps(item, ensure_ascii=False).encode("utf-8"))
            items.append(item)
            size += item_bytes
            if partial:
                # this message is full of one group's links; stop here
                return {"ok": True, "tid": tid, "items": items,
                        "next_gi": gi, "next_li": k, "done": False}
            # group finished; move to next group, reset link cursor
            gi += 1
            li = 0
            if size >= link_budget:
                break  # message is full enough
        done = gi >= len(groups)
        if done:
            _tx.pop(tid, None)
        return {"ok": True, "tid": tid, "items": items,
                "next_gi": gi, "next_li": li, "done": done}

    return {"ok": False, "error": "unknown_action"}


def _coalesce_fragments(groups):
    """Merge group fragments that share an id (partial link lists sent across
    multiple sync_chunk messages) into single groups, preserving order and
    link order. Non-fragmented input passes through unchanged."""
    order = []
    by_id = {}
    for g in groups or []:
        gid = g.get("id")
        if gid is None:
            continue
        if gid not in by_id:
            by_id[gid] = {"id": gid, "name": g.get("name", ""),
                          "collapsed": bool(g.get("collapsed", False)),
                          "createdAt": g.get("createdAt"),
                          "links": list(g.get("links", []) or [])}
            order.append(gid)
        else:
            # later fragment: keep first metadata, append links; update meta if
            # the first piece lacked it
            tgt = by_id[gid]
            tgt["links"].extend(g.get("links", []) or [])
            if not tgt.get("name") and g.get("name"):
                tgt["name"] = g["name"]
            if tgt.get("createdAt") is None and g.get("createdAt") is not None:
                tgt["createdAt"] = g["createdAt"]
    return [by_id[g] for g in order]


def _force_binary_stdio():
    """On Windows the std streams default to text mode with newline translation
    (\\n -> \\r\\n). Native messaging is a binary protocol: any translation
    corrupts the 4-byte length header and kills the port on the first message.
    Force both ends to raw binary. No-op on POSIX."""
    if os.name == "nt":
        try:
            import msvcrt
            msvcrt.setmode(sys.stdin.fileno(), os.O_BINARY)
            msvcrt.setmode(sys.stdout.fileno(), os.O_BINARY)
        except Exception:
            pass


def host_loop():
    _force_binary_stdio()
    while True:
        req = None
        try:
            req = _read_message()
            if req is None:
                break
            resp = handle(req)
        except Exception as e:
            resp = {"ok": False, "error": str(e), "trace": traceback.format_exc()}
        # echo the request id so the extension can match replies on the port
        if isinstance(req, dict) and req.get("rid") is not None:
            resp["rid"] = req["rid"]
        try:
            _send_message(resp)
        except Exception:
            break


# ---------- installer (Windows, HKCU, no admin) ----------
def install_main():
    import winreg
    if len(sys.argv) < 3:
        print("Usage: python tabstash_host.py install <EXTENSION_ID>")
        sys.exit(1)
    ext_id = sys.argv[2].strip()
    here = APP_DIR

    bat = here / "run_host.bat"
    if getattr(sys, "frozen", False):
        exe = Path(sys.executable).resolve()
        bat.write_text('@echo off\r\n"' + str(exe) + '" host\r\n', encoding="ascii")
    else:
        bat.write_text('@echo off\r\n"' + sys.executable + '" "' +
                       str(Path(__file__).resolve()) + '" host\r\n', encoding="ascii")

    manifest = {
        "name": HOST_NAME,
        "description": "TabStash native host",
        "path": str(bat),
        "type": "stdio",
        "allowed_origins": ["chrome-extension://" + ext_id + "/"],
    }
    mpath = here / (HOST_NAME + ".json")
    mpath.write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    key_path = r"Software\Google\Chrome\NativeMessagingHosts\\" + HOST_NAME
    with winreg.CreateKey(winreg.HKEY_CURRENT_USER, key_path) as k:
        winreg.SetValueEx(k, "", 0, winreg.REG_SZ, str(mpath))

    print("Installed native host for extension:", ext_id)
    print("Manifest:", mpath)


# ---------- import / export ----------
def export_groups(vault):
    return json.dumps({"groups": vault.get("groups", [])}, ensure_ascii=False, indent=2)


def import_groups(vault, text):
    obj = json.loads(text)
    items = obj.get("groups", obj) if isinstance(obj, dict) else obj
    if not isinstance(items, list):
        raise ValueError("Invalid format: expected groups list")
    by_id = {g.get("id"): g for g in vault["groups"]}
    ag = al = 0
    for g in items:
        if not isinstance(g, dict):
            continue
        gid = g.get("id") or _uid()
        links = g.get("links", []) or []
        if gid in by_id:
            tgt = by_id[gid]
            have = {l.get("id") for l in tgt["links"]}
            for l in links:
                lid = l.get("id") or _uid()
                if lid in have:
                    continue
                tgt["links"].append({"id": lid, "title": l.get("title", ""),
                                     "url": l.get("url", ""),
                                     "favIconUrl": l.get("favIconUrl", "")})
                have.add(lid)
                al += 1
        else:
            ng = {"id": gid, "name": g.get("name", ""),
                  "collapsed": bool(g.get("collapsed", False)),
                  "createdAt": g.get("createdAt") or int(time.time() * 1000),
                  "links": []}
            for l in links:
                ng["links"].append({"id": l.get("id") or _uid(),
                                    "title": l.get("title", ""),
                                    "url": l.get("url", ""),
                                    "favIconUrl": l.get("favIconUrl", "")})
                al += 1
            vault["groups"].append(ng)
            by_id[gid] = ng
            ag += 1
    return ag, al


def parse_pasted_links(text):
    out = []
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        title, url = "", ""
        if "|" in line:
            title, url = [p.strip() for p in line.split("|", 1)]
        elif "\t" in line:
            title, url = [p.strip() for p in line.split("\t", 1)]
        else:
            url = line
        if not url:
            continue
        if "://" not in url:
            url = "https://" + url
        if not title:
            title = _hostname(url)
        out.append({"id": _uid(), "title": title, "url": url, "favIconUrl": ""})
    return out


# ---------- GUI: full editor ----------
def run_gui():
    import tkinter as tk
    from tkinter import messagebox, simpledialog, filedialog

    BG, SURF, SURF2, LINE, TXT, MUT, ACC, ACC2, DEL = (
        "#14161b", "#1c1f26", "#232732", "#2c313c",
        "#e7eaf0", "#8b93a3", "#e0a458", "#5eddc4", "#e0685f")

    vault = load_vault()
    mt = [_vault_mtime()]  # last mtime the GUI knows about (its own writes included)

    root = tk.Tk()
    root.title("TabStash - editor")
    root.geometry("760x620")
    root.configure(bg=BG)

    top = tk.Frame(root, bg=BG)
    top.pack(fill="x", padx=12, pady=(12, 6))
    tk.Label(top, text="TabStash", bg=BG, fg=ACC,
             font=("Segoe UI", 15, "bold")).pack(side="left")
    info = tk.Label(top, text="", bg=BG, fg=MUT, font=("Segoe UI", 9))
    info.pack(side="left", padx=10)

    def tb(parent, text, cmd, fg=TXT):
        return tk.Button(parent, text=text, command=cmd, bg=SURF2, fg=fg,
                         relief="flat", cursor="hand2", font=("Segoe UI", 10),
                         padx=10, pady=4)

    tb(top, "Export", lambda: do_export()).pack(side="right", padx=3)
    tb(top, "Import", lambda: do_import()).pack(side="right", padx=3)
    tb(top, "Delete all duplicates", lambda: dedupe_all()).pack(side="right", padx=3)
    tb(top, "Paste links", lambda: paste_dialog(None)).pack(side="right", padx=3)
    tb(top, "New group", lambda: new_group()).pack(side="right", padx=3)

    canvas = tk.Canvas(root, bg=BG, highlightthickness=0)
    frame = tk.Frame(canvas, bg=BG)
    sb = tk.Scrollbar(root, orient="vertical", command=canvas.yview)
    canvas.configure(yscrollcommand=sb.set)
    sb.pack(side="right", fill="y")
    canvas.pack(fill="both", expand=True, padx=8, pady=8)
    cwin = canvas.create_window((0, 0), window=frame, anchor="nw")
    frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
    canvas.bind("<Configure>", lambda e: canvas.itemconfig(cwin, width=e.width))
    canvas.bind_all("<MouseWheel>", lambda e: canvas.yview_scroll(int(-e.delta / 120), "units"))

    def commit():
        save_vault(vault)
        mt[0] = _vault_mtime()  # our own write; don't treat it as external
        redraw()

    def group_by_id(gid):
        return next((g for g in vault["groups"] if g["id"] == gid), None)

    def new_group():
        name = simpledialog.askstring("New group", "Group name (optional):", parent=root) or ""
        vault["groups"].insert(0, {"id": _uid(), "name": name.strip(),
                                   "collapsed": False,
                                   "createdAt": int(time.time() * 1000), "links": []})
        commit()

    def rename_group(g, value):
        g["name"] = value.strip()
        save_vault(vault)

    def del_group(g):
        vault["groups"] = [x for x in vault["groups"] if x is not g]
        commit()

    def move_group(g, delta):
        i = vault["groups"].index(g)
        j = max(0, min(len(vault["groups"]) - 1, i + delta))
        if i != j:
            vault["groups"].insert(j, vault["groups"].pop(i))
            commit()

    def del_link(g, l):
        g["links"] = [x for x in g["links"] if x is not l]
        commit()

    def _link_key(l):
        # duplicates = same url AND same title
        return (l.get("url", ""), l.get("title", ""))

    def dedupe_group(g):
        seen = set()
        kept = []
        removed = 0
        for l in g.get("links", []):
            k = _link_key(l)
            if k in seen:
                removed += 1
            else:
                seen.add(k)
                kept.append(l)
        if not removed:
            messagebox.showinfo("Duplicates", "No duplicate links in this group.",
                                parent=root)
            return
        g["links"] = kept
        commit()
        messagebox.showinfo("Duplicates",
                            "Deleted " + str(removed) + " duplicate link(s).",
                            parent=root)

    def dedupe_all():
        # count first, so we can ask for confirmation before mutating anything
        seen = set()
        removed = 0
        for g in vault["groups"]:
            for l in g.get("links", []):
                k = _link_key(l)
                if k in seen:
                    removed += 1
                else:
                    seen.add(k)
        if not removed:
            messagebox.showinfo("Duplicates", "No duplicate links found.",
                                parent=root)
            return
        if not messagebox.askyesno("Delete all duplicates",
                                   "Permanently delete " + str(removed) +
                                   " duplicate link(s) across all groups?",
                                   parent=root):
            return
        # apply
        seen = set()
        for g in vault["groups"]:
            kept = []
            for l in g.get("links", []):
                k = _link_key(l)
                if k in seen:
                    continue
                seen.add(k)
                kept.append(l)
            g["links"] = kept
        commit()
        messagebox.showinfo("Duplicates",
                            "Deleted " + str(removed) + " duplicate link(s).",
                            parent=root)

    def move_link(g, l, delta):
        i = g["links"].index(l)
        j = max(0, min(len(g["links"]) - 1, i + delta))
        if i != j:
            g["links"].insert(j, g["links"].pop(i))
            commit()

    def copy_url(l):
        root.clipboard_clear()
        root.clipboard_append(l.get("url", ""))

    def open_link(l):
        try:
            webbrowser.open(l.get("url", ""))
        except Exception:
            pass

    def move_link_to(g, l):
        others = [x for x in vault["groups"] if x is not g]
        win = tk.Toplevel(root)
        win.title("Move to group")
        win.configure(bg=BG)
        tk.Label(win, text="Move link to:", bg=BG, fg=TXT,
                 font=("Segoe UI", 11, "bold")).pack(anchor="w", padx=12, pady=(10, 6))
        if not others:
            tk.Label(win, text="No other groups.", bg=BG, fg=MUT).pack(padx=12, pady=8)
        for x in others:
            def do(dst=x):
                g["links"] = [y for y in g["links"] if y is not l]
                dst["links"].append(l)
                win.destroy()
                commit()
            tk.Button(win, text=(x["name"] or "Untitled group"), command=do,
                      bg=SURF2, fg=TXT, relief="flat", cursor="hand2",
                      anchor="w", padx=10, pady=4).pack(fill="x", padx=12, pady=2)

    def paste_dialog(default_gid):
        win = tk.Toplevel(root)
        win.title("Paste links")
        win.geometry("520x420")
        win.configure(bg=BG)
        tk.Label(win, text="Paste one link per line", bg=BG, fg=TXT,
                 font=("Segoe UI", 12, "bold")).pack(anchor="w", padx=12, pady=(10, 2))
        tk.Label(win, text="Format: 'url'  or  'title | url'", bg=BG, fg=MUT,
                 font=("Segoe UI", 9)).pack(anchor="w", padx=12)
        txt = tk.Text(win, height=12, bg=SURF, fg=TXT, insertbackground=TXT,
                      relief="flat", font=("Consolas", 10))
        txt.pack(fill="both", expand=True, padx=12, pady=8)

        bar = tk.Frame(win, bg=BG)
        bar.pack(fill="x", padx=12, pady=(0, 10))
        tk.Label(bar, text="Into:", bg=BG, fg=MUT).pack(side="left")
        names = ["(new group)"] + [(g["name"] or "Untitled group") for g in vault["groups"]]
        sel = tk.StringVar(value=names[0])
        if default_gid:
            g0 = group_by_id(default_gid)
            if g0:
                sel.set(g0["name"] or "Untitled group")
        tk.OptionMenu(bar, sel, *names).pack(side="left", padx=6)

        def do_ok():
            links = parse_pasted_links(txt.get("1.0", "end-1c"))
            if not links:
                messagebox.showinfo("Nothing", "No links found.", parent=win)
                return
            choice = sel.get()
            if choice == "(new group)":
                g = {"id": _uid(), "name": "", "collapsed": False,
                     "createdAt": int(time.time() * 1000), "links": []}
                vault["groups"].insert(0, g)
            else:
                g = next((x for x in vault["groups"]
                          if (x["name"] or "Untitled group") == choice), None)
                if g is None:
                    g = vault["groups"][0]
            g["links"].extend(links)
            win.destroy()
            commit()

        tk.Button(bar, text="Add", command=do_ok, bg=ACC2, fg="#0d1411",
                  relief="flat", cursor="hand2", font=("Segoe UI", 10, "bold"),
                  padx=14, pady=4).pack(side="right")

    def do_export():
        path = filedialog.asksaveasfilename(
            parent=root, defaultextension=".json",
            initialfile="tabstash-" + time.strftime("%Y-%m-%d") + ".json",
            filetypes=[("JSON", "*.json")])
        if not path:
            return
        Path(path).write_text(export_groups(vault), encoding="utf-8")
        messagebox.showinfo("Exported", "Saved.", parent=root)

    def do_import():
        path = filedialog.askopenfilename(parent=root, filetypes=[("JSON", "*.json")])
        if not path:
            return
        try:
            ag, al = import_groups(vault, Path(path).read_text(encoding="utf-8"))
            commit()
            messagebox.showinfo("Imported", "Added " + str(ag) + " group(s), " +
                                str(al) + " link(s).", parent=root)
        except Exception as e:
            messagebox.showerror("Error", "Import failed:\n" + str(e), parent=root)

    # Lazy rendering: groups start collapsed (headers only) so the window opens
    # instantly even with thousands of links. Expanding a group builds its rows
    # in chunks via root.after so the UI never freezes. A build id cancels stale
    # builds when redraw() runs again.
    expanded = set()
    build_id = [0]

    def _mk_head(box, g):
        head = tk.Frame(box, bg=SURF)
        head.pack(fill="x", padx=8, pady=6)
        exp = tk.Button(head, text=("\u25be" if g["id"] in expanded else "\u25b8"),
                        bg=SURF, fg=MUT, relief="flat", cursor="hand2",
                        font=("Segoe UI", 10), width=2,
                        command=lambda gg=g: _toggle(gg))
        exp.pack(side="left")
        nm = tk.Entry(head, bg=SURF2, fg=TXT, insertbackground=TXT, relief="flat",
                      font=("Segoe UI", 11, "bold"))
        nm.insert(0, g.get("name", ""))
        nm.pack(side="left", fill="x", expand=True, ipady=3)
        nm.bind("<Return>", lambda e, gg=g, w=nm: (rename_group(gg, w.get()), redraw()))
        nm.bind("<FocusOut>", lambda e, gg=g, w=nm: rename_group(gg, w.get()))

        def mk(text, cmd, fg=MUT):
            return tk.Button(head, text=text, command=cmd, bg=SURF, fg=fg,
                             relief="flat", cursor="hand2", font=("Segoe UI", 9), padx=6)
        tk.Label(head, text=str(len(g.get("links", []))), bg=SURF, fg=MUT,
                 font=("Segoe UI", 9)).pack(side="right", padx=(4, 8))
        mk("\uff0b links", lambda gg=g: paste_dialog(gg["id"]), ACC2).pack(side="right")
        mk("Delete duplicates", lambda gg=g: dedupe_group(gg)).pack(side="right")
        mk("\u25b2", lambda gg=g: move_group(gg, -1)).pack(side="right")
        mk("\u25bc", lambda gg=g: move_group(gg, +1)).pack(side="right")
        mk("Delete", lambda gg=g: del_group(gg), DEL).pack(side="right", padx=(0, 6))

    def _mk_row(container, g, l):
        row = tk.Frame(container, bg=BG)
        row.pack(fill="x", padx=10, pady=1)
        title = tk.Label(row, text=l.get("title") or l.get("url"), bg=BG, fg=TXT,
                         font=("Segoe UI", 10), anchor="w", cursor="hand2")
        title.pack(side="left", fill="x", expand=True)
        title.bind("<Double-Button-1>", lambda e, ll=l: open_link(ll))
        tk.Label(row, text=_hostname(l.get("url", "")), bg=BG, fg=MUT,
                 font=("Segoe UI", 8)).pack(side="left", padx=6)

        def mkl(text, cmd, fg=MUT):
            return tk.Button(row, text=text, command=cmd, bg=BG, fg=fg,
                             relief="flat", cursor="hand2", font=("Segoe UI", 9))
        mkl("\u2715", lambda gg=g, ll=l: del_link(gg, ll), DEL).pack(side="right")
        mkl("\u2192", lambda gg=g, ll=l: move_link_to(gg, ll)).pack(side="right")
        mkl("\u25bc", lambda gg=g, ll=l: move_link(gg, ll, +1)).pack(side="right")
        mkl("\u25b2", lambda gg=g, ll=l: move_link(gg, ll, -1)).pack(side="right")
        mkl("Copy", lambda ll=l: copy_url(ll), ACC2).pack(side="right", padx=(0, 4))
        mkl("Open", lambda ll=l: open_link(ll)).pack(side="right")

    def _build_links(container, g, i, my):
        if my != build_id[0]:
            return
        links = g.get("links", [])
        end = min(i + 80, len(links))
        for k in range(i, end):
            _mk_row(container, g, links[k])
        if end < len(links):
            root.after(1, lambda: _build_links(container, g, end, my))

    def _build_groups(i, my):
        if my != build_id[0]:
            return
        end = min(i + 20, len(vault["groups"]))
        for k in range(i, end):
            g = vault["groups"][k]
            box = tk.Frame(frame, bg=SURF, highlightbackground=LINE, highlightthickness=1)
            box.pack(fill="x", padx=4, pady=6)
            _mk_head(box, g)
            if g["id"] in expanded:
                lc = tk.Frame(box, bg=BG)
                lc.pack(fill="x")
                _build_links(lc, g, 0, my)
        if end < len(vault["groups"]):
            root.after(1, lambda: _build_groups(end, my))

    def _toggle(g):
        if g["id"] in expanded:
            expanded.discard(g["id"])
        else:
            expanded.add(g["id"])
        redraw()

    def redraw():
        build_id[0] += 1
        my = build_id[0]
        for w in frame.winfo_children():
            w.destroy()
        n = sum(len(g.get("links", [])) for g in vault["groups"])
        info.config(text=str(len(vault["groups"])) + " groups \u00b7 " + str(n) +
                    " tabs  (click \u25b8 to expand)")
        if not vault["groups"]:
            tk.Label(frame, text="Empty. Use New group or Paste links.",
                     bg=BG, fg=MUT, font=("Segoe UI", 10)).pack(anchor="w", padx=8, pady=20)
            return
        _build_groups(0, my)

    def _poll():
        nonlocal vault
        cur = _vault_mtime()
        if cur and cur != mt[0]:
            w = root.focus_get()
            if isinstance(w, (tk.Entry, tk.Text)):
                pass  # user is editing; retry next tick, don't clobber
            else:
                mt[0] = cur
                vault = load_vault()  # external change (browser action) -> reload
                redraw()
        root.after(1000, _poll)

    redraw()
    root.after(1000, _poll)
    root.mainloop()


# ---------- entry point ----------
def main():
    if len(sys.argv) < 2:
        run_gui()
        return
    cmd = sys.argv[1].lower()
    if cmd == "gui":
        run_gui()
    elif cmd == "host":
        host_loop()
    elif cmd == "install":
        install_main()
    elif cmd == "dump":
        # write UTF-8 straight to the binary buffer so non-cp1252 chars
        # (emoji, CJK) don't crash on the Windows console
        out = json.dumps(load_vault(), indent=2, ensure_ascii=False)
        sys.stdout.buffer.write(out.encode("utf-8"))
        sys.stdout.buffer.write(b"\n")
        sys.stdout.buffer.flush()
    else:
        print("Unknown command:", cmd)
        sys.exit(1)


if __name__ == "__main__":
    main()