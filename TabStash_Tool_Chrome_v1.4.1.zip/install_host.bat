@echo off
setlocal EnableDelayedExpansion
REM ============================================================
REM  Register the TabStash native host for the Chrome extension.
REM  Opens a text file: paste the extension ID, save & close.
REM ============================================================

set "DEST_DIR=%~dp0"
set "ID_FILE=%DEST_DIR%extension_id.txt"
set "PY_FILE=%DEST_DIR%tabstash_host.py"
set "EXE_FILE=%DEST_DIR%dist\tabstash_host.exe"

if not exist "%PY_FILE%" if not exist "%EXE_FILE%" (
    echo ERROR: neither tabstash_host.py nor dist\tabstash_host.exe found here.
    echo Put this .bat next to tabstash_host.py
    pause
    exit /b 1
)

> "%ID_FILE%" echo # Paste your extension ID on the first line below (only the ID),
>> "%ID_FILE%" echo # find it in chrome://extensions (Developer mode) after loading it.
>> "%ID_FILE%" echo # Then SAVE (Ctrl+S) and CLOSE this window.
>> "%ID_FILE%" echo # your_extension_id_here

start /wait notepad "%ID_FILE%"

set "EXT_ID="
for /f "usebackq tokens=* delims= " %%L in ("%ID_FILE%") do (
    set "line=%%L"
    if not "!line!"=="" (
        set "first=!line:~0,1!"
        if not "!first!"=="#" (
            if not defined EXT_ID set "EXT_ID=!line!"
        )
    )
)

if not defined EXT_ID (
    echo ERROR: no extension ID found. Run again and paste the ID.
    del "%ID_FILE%" 2>nul
    pause
    exit /b 1
)
set "EXT_ID=!EXT_ID: =!"

echo Registering native host for extension ID: !EXT_ID!
cd /d "%DEST_DIR%"
if exist "%EXE_FILE%" (
    "%EXE_FILE%" install !EXT_ID!
) else (
    python "%PY_FILE%" install !EXT_ID!
)

del "%ID_FILE%" 2>nul
echo.
echo Done. Reload the extension page and click "Sync".
pause
exit /b 0
