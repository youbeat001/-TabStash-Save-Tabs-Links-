@echo off
"C:\Users\SilverRabbit90\AppData\Local\Programs\Python\Python312\python.exe" "C:\Users\SilverRabbit90\Desktop\Fold\--- Shortcuts\__tabstash-tool_Chrome\TabStash_Tool_Chrome\tabstash_host.py" host
