@echo off
REM ============================================================================
REM  register_firefox_host_v3.bat - TabStash native host for Firefox / Mullvad
REM
REM  Does everything from the folder it is launched from:
REM    1. finds tabstash_host.py (this folder or one level below)
REM    2. finds python.exe
REM    3. creates run_host.bat next to the .py, if missing
REM    4. writes com.tabstash.host.firefox.json (replacing any existing one)
REM    5. registers the host for Firefox-based browsers
REM
REM  Optional: force a specific interpreter ->  register_firefox_host_v3.bat "C:\...\python.exe"
REM  Reuse for another extension: change the CONFIG block below.
REM ============================================================================

setlocal enabledelayedexpansion

REM ---------------- CONFIG ----------------
set "HOST_NAME=com.tabstash.host"
set "EXT_ID=tabstash@silverrabbit.local"
set "DESCR=TabStash encrypted vault native host"
set "OUTNAME=com.tabstash.host.firefox.json"
set "PYNAME=tabstash_host.py"
set "RUNNAME=run_host.bat"
set "HOSTARG=host"
REM ----------------------------------------

set "HERE=%~dp0"
if "%HERE:~-1%"=="\" set "HERE=%HERE:~0,-1%"
set "MANIFEST=%HERE%\%OUTNAME%"

echo Working folder : %HERE%

REM ---- 1) locate the python host script ----
set "HOSTPY="
if exist "%HERE%\%PYNAME%" set "HOSTPY=%HERE%\%PYNAME%"
if not defined HOSTPY (
    for /d %%D in ("%HERE%\*") do (
        if not defined HOSTPY if exist "%%~fD\%PYNAME%" set "HOSTPY=%%~fD\%PYNAME%"
    )
)
if not defined HOSTPY (
    echo [ERROR] %PYNAME% not found in this folder or one level below.
    echo         Put this script in the tool folder and run it again.
    pause
    exit /b 1
)
for %%F in ("!HOSTPY!") do set "TOOLDIR=%%~dpF"
if "!TOOLDIR:~-1!"=="\" set "TOOLDIR=!TOOLDIR:~0,-1!"
echo Host script    : !HOSTPY!

REM ---- 2) locate python.exe ----
set "PY="
if not "%~1"=="" set "PY=%~f1"

if not defined PY (
    for /d %%D in ("%LOCALAPPDATA%\Programs\Python\Python3*") do (
        if not defined PY if exist "%%~fD\python.exe" set "PY=%%~fD\python.exe"
    )
)
if not defined PY (
    for /d %%D in ("%ProgramFiles%\Python3*") do (
        if not defined PY if exist "%%~fD\python.exe" set "PY=%%~fD\python.exe"
    )
)
if not defined PY (
    REM last resort: PATH, skipping the Microsoft Store stub
    for /f "delims=" %%P in ('where python.exe 2^>nul') do (
        if not defined PY (
            echo %%P | find /i "WindowsApps" >nul || set "PY=%%P"
        )
    )
)
if not defined PY (
    echo [ERROR] python.exe not found. Pass it explicitly:
    echo             %~nx0 "C:\full\path\to\python.exe"
    pause
    exit /b 1
)
if not exist "!PY!" (
    echo [ERROR] Interpreter not found: !PY!
    pause
    exit /b 1
)
echo Interpreter    : !PY!

REM ---- 3) create run_host.bat next to the .py, only if missing ----
set "RUNBAT=!TOOLDIR!\%RUNNAME%"
if exist "!RUNBAT!" (
    echo Launcher       : !RUNBAT!  [already present, left untouched]
) else (
    > "!RUNBAT!" (
        echo @echo off
        echo "!PY!" "!HOSTPY!" %HOSTARG%
    )
    if not exist "!RUNBAT!" (
        echo [ERROR] Could not create !RUNBAT!
        pause
        exit /b 1
    )
    echo Launcher       : !RUNBAT!  [created]
)

REM ---- 4) write the manifest, replacing any existing one ----
set "JSONPATH=!RUNBAT:\=\\!"
if exist "%MANIFEST%" del /f /q "%MANIFEST%" >nul 2>&1

> "%MANIFEST%" (
    echo {
    echo   "name": "%HOST_NAME%",
    echo   "description": "%DESCR%",
    echo   "path": "!JSONPATH!",
    echo   "type": "stdio",
    echo   "allowed_extensions": ["%EXT_ID%"]
    echo }
)
if not exist "%MANIFEST%" (
    echo [ERROR] Could not write %MANIFEST%
    pause
    exit /b 1
)
echo Manifest       : %MANIFEST%
echo.

echo ---- run_host.bat ----
type "!RUNBAT!"
echo ---- manifest --------
type "%MANIFEST%"
echo ----------------------
echo.

REM ---- 5) register for Firefox-based browsers ----
reg add "HKCU\Software\Mozilla\NativeMessagingHosts\%HOST_NAME%" /ve /t REG_SZ /d "%MANIFEST%" /f >nul
if errorlevel 1 (
    echo [ERROR] Could not write the registry key.
    pause
    exit /b 1
)

echo [OK] Registry key written:
reg query "HKCU\Software\Mozilla\NativeMessagingHosts\%HOST_NAME%"
echo.
echo Restart the browser completely, then check the badge (green = connected).
pause
endlocal